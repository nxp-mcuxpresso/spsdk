# -*- coding: UTF-8 -*-
#
# Copyright {% now 'local', '%Y' %} {{ cookiecutter.full_name }}
{% if cookiecutter.open_source_license != 'Not open source' -%}
#
# SPDX-License-Identifier: {{cookiecutter.open_source_license}}{% endif %}
"""Main module for {{ cookiecutter.project_name }}."""

from typing import Any, Dict, List, Optional

from typing_extensions import Self

from spsdk.utils.interfaces.device.base import DeviceBase
{% if cookiecutter.protocol_type == 'mboot' and cookiecutter.protocol_communication == 'serial' -%}
from spsdk.mboot.protocol.serial_protocol import MbootSerialProtocol
{% elif cookiecutter.protocol_type == 'sdp' and cookiecutter.protocol_communication == 'serial' -%}
from spsdk.sdp.protocol.serial_protocol import SDPSerialProtocol
{% elif cookiecutter.protocol_type == 'mboot' and cookiecutter.protocol_communication == 'bulk' -%}
from spsdk.mboot.protocol.bulk_protocol import MbootBulkProtocol
{% elif cookiecutter.protocol_type == 'sdp' and cookiecutter.protocol_communication == 'bulk' -%}
from spsdk.sdp.protocol.bulk_protocol import SDPBulkProtocol
{% endif %}


class {{ cookiecutter.device_class_name }}(DeviceBase):
    def __init__(self) -> None:
        """Initialize the device."""
        super().__init__()

    @property
    def timeout(self) -> int:
        """Timeout property."""
        pass

    @timeout.setter
    def timeout(self, value: int) -> None:
        """Timeout property setter."""
        pass

    @property
    def is_opened(self) -> bool:
        """Indicates whether device is open."""
        # TODO: Device is_opened property implementation comes here.
        raise NotImplementedError()

    def open(self) -> None:
        """Open the device."""
        # TODO: Device open implementation comes here.
        raise NotImplementedError()

    def close(self) -> None:
        """Close the device."""
        # TODO: Device close implementation comes here.
        raise NotImplementedError()

    def read(self, length: int, timeout: Optional[int] = None) -> bytes:
        """Read 'length' amount for bytes from device."""
        # TODO: Device read implementation comes here.
        raise NotImplementedError()

    def write(self, data: bytes, timeout: Optional[int] = None) -> None:
        """Send data to device."""
        # TODO: Device write implementation comes here.
        raise NotImplementedError()

    def __str__(self) -> str:
        """Return information about the device."""
        # TODO: Update this based on the implementation
        return "{{ cookiecutter.project_slug }}"


{% if cookiecutter.protocol_type == 'mboot' and cookiecutter.protocol_communication == 'serial' -%}
class {{ cookiecutter.interface_class }}(MbootSerialProtocol):
{% elif cookiecutter.protocol_type == 'sdp' and cookiecutter.protocol_communication == 'serial' -%}
class {{ cookiecutter.interface_class }}(SDPSerialProtocol):
{% elif cookiecutter.protocol_type == 'mboot' and cookiecutter.protocol_communication == 'bulk' -%}
class {{ cookiecutter.interface_class }}(MbootBulkProtocol):
{% elif cookiecutter.protocol_type == 'sdp' and cookiecutter.protocol_communication == 'bulk' -%}
class {{ cookiecutter.interface_class }}(SDPBulkProtocol):
{%- endif %}    """Custom interface class."""

    # identifier of the device interface; used as command line parameter in spsdk apps
    identifier = "{{ cookiecutter.interface_identifier }}"

    def __init__(self, device: {{ cookiecutter.device_class_name }}) -> None:
        """Initialize the {{ cookiecutter.interface_class }}."""
        self.device = device

    @classmethod
    def scan(cls, arg1: Any, arg2: Any, timeout: Optional[int] = None) -> List[Self]:
        """Scan the existing interfaces."""
        # TODO: Interface scanning functionality comes here.
        raise NotImplementedError()
