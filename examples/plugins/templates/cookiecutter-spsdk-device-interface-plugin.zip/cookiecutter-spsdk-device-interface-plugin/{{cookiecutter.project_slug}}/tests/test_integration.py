#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
# Copyright {% now 'local', '%Y' %} {{ cookiecutter.full_name }}
{% if cookiecutter.open_source_license != 'Not open source' -%}
#
# SPDX-License-Identifier: {{cookiecutter.open_source_license}}{% endif %}
"""Tests for `{{ cookiecutter.project_slug }}` package."""

from spsdk.utils.interfaces.protocol.protocol_base import ProtocolBase
from {{ cookiecutter.pypi_project }} import {{ cookiecutter.interface_class }}


def test_integration() -> None:
    cls = ProtocolBase.get_interface_class("{{ cookiecutter.interface_identifier }}")
    assert cls == {{ cookiecutter.interface_class }}
