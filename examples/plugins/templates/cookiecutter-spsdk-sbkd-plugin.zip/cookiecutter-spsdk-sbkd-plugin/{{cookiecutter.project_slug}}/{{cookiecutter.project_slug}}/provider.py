# -*- coding: UTF-8 -*-
#
# Copyright {% now 'local', '%Y' %} {{ cookiecutter.full_name }}
{% if cookiecutter.open_source_license != 'Not open source' -%}
#
# SPDX-License-Identifier: {{cookiecutter.open_source_license}}{% endif %}
"""Main module for {{ cookiecutter.service_provider_class }}."""

{{ cookiecutter._spsdk_base_class_import }}

class {{ cookiecutter.service_provider_class }}({{ cookiecutter._spsdk_base_class }}):
    """Signature Provider based on a remote signing service."""

    # identifier of this signature provider; used in yaml configuration file
    identifier = "{{ cookiecutter.service_provider_identifier }}"

    def __init__(self) -> None:
        """Initialize the {{ cookiecutter.service_provider_class }}."""
        super().__init__()

    def remote_cmac(self, data: bytes) -> bytes:
        """Calculate CMAC using the implementation-specific method.

        :param data: Input data for CMAC calculation
        :return: Calculated CMAC value
        """
        raise NotImplementedError()
