# -*- coding: UTF-8 -*-
#
# Copyright {% now 'local', '%Y' %} {{ cookiecutter.full_name }}
{% if cookiecutter.open_source_license != 'Not open source' -%}
#
# SPDX-License-Identifier: {{cookiecutter.open_source_license}}{% endif %}
"""Main module for {{ cookiecutter.project_name }}."""

import logging

from typing import Dict, Optional


from spsdk.debuggers.debug_probe import (
    DebugProbeCoreSightOnly,
    DebugProbes,
    ProbeDescription,
    SPSDKDebugProbeError,
    SPSDKDebugProbeNotOpenError,
    SPSDKDebugProbeTransferError,
)

logger = logging.getLogger(__name__)


class {{ cookiecutter.class_name }}(DebugProbeCoreSightOnly):
    """SPSDK Debug Probe {{ cookiecutter.project_name }} class."""

    NAME = "{{ cookiecutter.debug_probe_name }}"

    def __init__(self, hardware_id: str, options: Optional[Dict] = None) -> None:
        """The Debug Probe class initialization."""
        super().__init__(hardware_id, options)
        # Write your code here

    @classmethod
    def get_connected_probes(
        cls, hardware_id: Optional[str] = None, options: Optional[Dict] = None
    ) -> DebugProbes:
        """Functions returns the list of all connected probes in system.

        There is option to look for just for one debug probe defined by its hardware ID.

        :param hardware_id: None to list all probes, otherwise the the only probe with
            matching hardware id is listed.
        :param options: The options dictionary
        :return: List of ProbeDescription
        """
        probes = DebugProbes()

        # Write your code here
        # For example
        probes.append(
            ProbeDescription(
                interface="{{ cookiecutter.debug_probe_name }}",
                hardware_id=0x12345,
                description="{{ cookiecutter.debug_probe_name }} probe",
                probe=cls,
            )
        )

        return probes

    @staticmethod
    def get_options_help() -> Dict[str, str]:
        """Get full list of options of debug probe.

        :return: Dictionary with individual options. Key is parameter name and value the help text.
        """
        # Write your code here
        return {}

    def open(self) -> None:
        """Debug probe open.

        General opening function for SPSDK library to support various DEBUG PROBES.
        The function is used to initialize the connection to target and enable using debug probe
        for DAT purposes.
        """
        # Write your code here
        pass

    def close(self) -> None:
        """Debug probe close.

        This is general closing function for SPSDK library to support various DEBUG PROBES.
        """
        # Write your code here
        pass

    def coresight_reg_read(self, access_port: bool = True, addr: int = 0) -> int:
        """Read coresight register.

        It reads coresight register function for SPSDK library to support various DEBUG PROBES.

        :param access_port: if True, the Access Port (AP) register will be read(default), otherwise the Debug Port
        :param addr: the register address
        :return: The read value of addressed register (4 bytes)
        """
        logger.debug(f"CS READ: AP: {access_port}, ADDR: {addr:#x}")
        try:

            # Write your code here
            return 0

        except Exception as e:
            raise SPSDKDebugProbeTransferError(str(e)) from e

    def coresight_reg_write(self, access_port: bool = True, addr: int = 0, data: int = 0) -> None:
        """Write coresight register.

        It writes coresight register function for SPSDK library to support various DEBUG PROBES.

        :param access_port: if True, the Access Port (AP) register will be write(default), otherwise the Debug Port
        :param addr: the register address
        :param data: the data to be written into register
        """
        logger.debug(f"CS WRITE: AP: {access_port}, ADDR: {addr:#x}")
        try:

            # Write your code here
            pass

        except Exception as e:
            raise SPSDKDebugProbeTransferError(str(e)) from e

    def assert_reset_line(self, assert_reset: bool = False) -> None:
        """Control reset line at a target.

        :param assert_reset: If True, the reset line is asserted(pulled down), if False the reset line is not affected.
        """
        # Write your code here
        pass

    def __str__(self) -> str:
        """Return information about the device."""
        # Write your code here
        return "{{ cookiecutter.debug_probe_name }} debug probe"
