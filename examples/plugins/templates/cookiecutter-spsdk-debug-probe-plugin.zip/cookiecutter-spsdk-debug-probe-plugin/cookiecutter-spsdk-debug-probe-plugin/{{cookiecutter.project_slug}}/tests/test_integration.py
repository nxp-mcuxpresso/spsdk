#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
# Copyright {% now 'local', '%Y' %} {{ cookiecutter.full_name }}
{% if cookiecutter.open_source_license != 'Not open source' -%}
#
# SPDX-License-Identifier: {{cookiecutter.open_source_license}}{% endif %}
"""Tests for `{{ cookiecutter.project_slug }}` package integration in SPSDK."""

from click.testing import CliRunner
from spsdk.apps import nxpdebugmbox


def test_integration():
    runner = CliRunner()
    result = runner.invoke(nxpdebugmbox.main, "--help")
    assert "{{ cookiecutter.debug_probe_name }}" in result.output
