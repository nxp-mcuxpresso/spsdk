SPSDK SignatureProvider template
================================

This template uses [Cookiecutter](https://github.com/cookiecutter/cookiecutter) and it's based on (90+% copy of) [pypackage](https://github.com/audreyfeldroy/cookiecutter-pypackage) cookiecutter template

Quickstart:
1) Install cookiecutter: `pip install cookiecutter`
2) Create your SPSDK SP plugin: `cookiecutter https://github.com/nxp-mcuxpresso/spsdk/raw/master/examples/plugins/templates/cookiecutter-spsdk-sp-plugin.zip`
3) Implement (at least) the `sign` method and the `signature_length` property
4) Profit! :D
