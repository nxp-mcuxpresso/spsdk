# -*- coding: UTF-8 -*-
#
# Copyright {% now 'local', '%Y' %} {{ cookiecutter.full_name }}
{% if cookiecutter.open_source_license != 'Not open source' -%}
#
# SPDX-License-Identifier: {{cookiecutter.open_source_license}}{% endif %}
"""Main module for {{ cookiecutter.signature_provider_class }}."""

from spsdk.crypto.signature_provider import SignatureProvider


class {{ cookiecutter.signature_provider_class }}(SignatureProvider):
    """Signature Provider based on a remote signing service."""

    # identifier of this signature provider; used in yaml configuration file
    identifier = "{{ cookiecutter.signature_provider_identifier }}"

    def __init__(self) -> None:
        """Initialize the {{ cookiecutter.signature_provider_class }}."""
        super().__init__()

    def sign(self, data: bytes) -> bytes:
        """Return signature for data."""
        raise NotImplementedError()

    @property
    def signature_length(self) -> int:
        """Return length of the signature."""
        raise NotImplementedError()

    def verify_public_key(self, public_key: bytes) -> bool:
        """Verify if given public key matches private key."""
        return super().verify_public_key(public_key=public_key)

    def info(self) -> str:
        """Provide information about the Signature provider."""
        return super().info()
