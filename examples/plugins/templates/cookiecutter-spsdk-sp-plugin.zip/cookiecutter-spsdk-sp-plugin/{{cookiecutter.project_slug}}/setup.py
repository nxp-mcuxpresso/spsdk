#!/usr/bin/env python

"""The setup script."""

from setuptools import setup, find_packages

with open("README.rst") as readme_file:
    readme = readme_file.read()

with open("HISTORY.rst") as history_file:
    history = history_file.read()

requirements = ["spsdk>=1.9"]

test_requirements = [{%- if cookiecutter.use_pytest == "y" %}"pytest>=3"{%- endif %}]

{%- set license_classifiers = {
    "MIT": "License :: OSI Approved :: MIT License",
    "BSD-3-Clause": "License :: OSI Approved :: BSD 3-Clause 'New' or 'Revised' License",
    "ISC": "License :: OSI Approved :: ISC License (ISCL)",
    "Apache-2.0": "License :: OSI Approved :: Apache Software License 2.0",
    "GPL-3.0-only": "License :: OSI Approved :: GNU General Public License v3 (GPLv3)"
} %}

setup(
    author="{{ cookiecutter.full_name.replace('\"', '\\\"') }}",
    author_email="{{ cookiecutter.email }}",
    python_requires=">=3.7",
    classifiers=[
        "Development Status :: 2 - Pre-Alpha",
        "Intended Audience :: Developers",
{%- if cookiecutter.open_source_license in license_classifiers %}
        "{{ license_classifiers[cookiecutter.open_source_license] }}",
{%- endif %}
        "Natural Language :: English",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    description="{{ cookiecutter.project_short_description }}",
    install_requires=requirements,
{%- if cookiecutter.open_source_license in license_classifiers %}
    license="{{ cookiecutter.open_source_license }}",
{%- endif %}
    long_description=readme + "\n\n" + history,
    include_package_data=True,
    keywords="{{ cookiecutter.project_slug }}",
    name="{{ cookiecutter.project_slug }}",
    packages=find_packages(
        include=["{{ cookiecutter.project_slug }}", "{{ cookiecutter.project_slug }}.*"],
    ),
    test_suite="tests",
    tests_require=test_requirements,
    url="https://github.com/{{ cookiecutter.github_username }}/{{ cookiecutter.project_slug }}",
    version="{{ cookiecutter.version }}",
    zip_safe=False,
    entry_points={
        "spsdk.sp": [
            "{{ cookiecutter.signature_provider_type }} = {{ cookiecutter.project_slug }}.{{ cookiecutter.project_slug }}",
        ]
    },
)
