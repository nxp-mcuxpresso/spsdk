#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
# Copyright {% now 'local', '%Y' %} {{ cookiecutter.full_name }}
{% if cookiecutter.open_source_license != 'Not open source' -%}
#
# SPDX-License-Identifier: {{cookiecutter.open_source_license}}{% endif %}
"""Tests for `{{ cookiecutter.project_slug }}` package."""

from spsdk.crypto.signature_provider import SignatureProvider

from {{ cookiecutter.pypi_project }} import {{ cookiecutter.signature_provider_class }}


def test_registration() -> None:
    """Test whether {{ cookiecutter.signature_provider_class }} got picked up by SPSDK."""
    assert {{ cookiecutter.signature_provider_class }}.identifier in SignatureProvider.get_types()
