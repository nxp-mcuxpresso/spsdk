#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
# Copyright {% now 'local', '%Y' %} {{ cookiecutter.full_name }}
{% if cookiecutter.open_source_license != 'Not open source' -%}
#
# SPDX-License-Identifier: {{cookiecutter.open_source_license}}{% endif %}
"""Tests for `{{ cookiecutter.project_slug }}` package."""

{% if cookiecutter.use_pytest == 'y' -%}
import pytest
{% else %}
import unittest
{%- endif %}
from spsdk.crypto.signature_provider import SignatureProvider

from {{ cookiecutter.project_slug }} import {{ cookiecutter.signature_provider_class }}


{%- if cookiecutter.use_pytest == 'y' %}


def test_registration():
    """Test whether {{ cookiecutter.signature_provider_class }} got picked up by SPSDK."""
    assert {{ cookiecutter.signature_provider_class }}.sp_type in SignatureProvider.get_types()

{%- else %}


class Test{{ cookiecutter.project_slug|title }}(unittest.TestCase):
    """Tests for `{{ cookiecutter.project_slug }}` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_registration(self):
        """Test whether {{ cookiecutter.signature_provider_class }} got picked up by SPSDK."""
        self.assertIn({{ cookiecutter.signature_provider_class }}.sp_type, SignatureProvider.get_types())

{%- endif %}
