# -*- coding: UTF-8 -*-
#
# Copyright {% now 'local', '%Y' %} {{ cookiecutter.full_name }}
{% if cookiecutter.open_source_license != 'Not open source' -%}
#
# SPDX-License-Identifier: {{cookiecutter.open_source_license}}{% endif %}
"""Main module for {{ cookiecutter.service_provider_class }}."""

from typing import Optional

from spsdk.utils.family import FamilyRevision
from spsdk.wpc.wpc import WPCCertChain, WPCCertificateService, WPCIdType


class {{ cookiecutter.service_provider_class }}(WPCCertificateService):
    """WPC Service Provider."""

    # identifier of this service provider; used in yaml configuration file
    identifier = "{{ cookiecutter.service_provider_identifier }}"

    def __init__(self, param1: str, param2: int) -> None:
        """Initialize the MyWPCService."""
        super().__init__()
        self.param1 = param1
        self.param2 = param2

    @classmethod
    def get_validation_schemas(cls, family: FamilyRevision) -> list[dict]:
        """Get JSON schema for validating configuration data."""
        # Although this method not strictly necessary for the Service to work
        # it's highly recommended to implement it.
        # Defining this method will allow you to generate configuration templates
        # and validate configuration data.
        # If you choose not to use template generation and config data validation,
        # simply return an empty dictionary.
        return [
                {
                "type": "object",
                "properties": {
                    "param1": {
                        "type": "string",
                        "title": "Param1",
                        "description": "Param1 for MyWPCService",
                        "template_value": "something",
                    },
                    "param2": {
                        "type": "number",
                        "title": "Param2",
                        "description": "Param2 for MyWPCService",
                        "template_value": 123,
                    },
                },
                "required": ["param1", "param2"],
                }
            ]

    def get_wpc_cert(
        self, wpc_id_data: str, wpc_id_type: Optional[WPCIdType] = None
    ) -> WPCCertChain:
        """Obtain the WPC Certificate Chain.

        :param wpc_id_data: WPC ID provided by the target
        :param wpc_id_type: WPC ID type, defaults to None
        :return: WPC Certificate Chain
        """
        raise NotImplementedError()
