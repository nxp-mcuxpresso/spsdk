#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
# Copyright {% now 'local', '%Y' %} {{ cookiecutter.full_name }}
{% if cookiecutter.open_source_license != 'Not open source' -%}
#
# SPDX-License-Identifier: {{cookiecutter.open_source_license}}{% endif %}
"""Tests for `{{ cookiecutter.project_slug }}` package."""

{% if cookiecutter.use_pytest == 'y' -%}
import pytest
{% else %}
import unittest
{%- endif %}
from spsdk.wpc.utils import WPCCertificateService

from {{ cookiecutter.project_slug }} import {{ cookiecutter.service_provider_class }}


{%- if cookiecutter.use_pytest == 'y' %}


def test_registration():
    """Test whether {{ cookiecutter.service_provider_class }} got picked up by SPSDK."""
    assert {{ cookiecutter.service_provider_class }}.NAME in WPCCertificateService.get_providers()

{%- else %}


class Test{{ cookiecutter.project_slug|title }}(unittest.TestCase):
    """Tests for `{{ cookiecutter.project_slug }}` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_registration(self):
        """Test whether {{ cookiecutter.service_provider_class }} got picked up by SPSDK."""
        self.assertIn({{ cookiecutter.service_provider_class }}.NAME, WPCCertificateService.get_providers())

{%- endif %}
