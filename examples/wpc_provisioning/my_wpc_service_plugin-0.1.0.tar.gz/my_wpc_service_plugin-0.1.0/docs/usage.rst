=====
Usage
=====

To use My WPC Service Plugin in a project::

    import my_wpc_service_plugin
