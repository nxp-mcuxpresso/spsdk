=====================
My WPC Service Plugin
=====================


.. image:: https://img.shields.io/pypi/v/my_wpc_service_plugin.svg
        :target: https://pypi.python.org/pypi/my_wpc_service_plugin

.. image:: https://img.shields.io/travis/me/my_wpc_service_plugin.svg
        :target: https://travis-ci.com/me/my_wpc_service_plugin

.. image:: https://readthedocs.org/projects/my-wpc-service-plugin/badge/?version=latest
        :target: https://my-wpc-service-plugin.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status




My WPC Service plugin for SPSDK.


* Free software: MIT
* Documentation: https://my-wpc-service-plugin.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
