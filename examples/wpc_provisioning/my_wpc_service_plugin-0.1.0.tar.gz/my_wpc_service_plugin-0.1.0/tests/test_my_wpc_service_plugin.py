#!/usr/bin/env python
# -*- coding: UTF-8 -*-
#
# Copyright 2024 First Last
#
# SPDX-License-Identifier: MIT
"""Tests for `my_wpc_service_plugin` package."""

import pytest

from spsdk.wpc.utils import WPCCertificateService

from my_wpc_service_plugin import MyWPCService


def test_registration():
    """Test whether MyWPCService got picked up by SPSDK."""
    assert MyWPCService.NAME in WPCCertificateService.get_providers()
