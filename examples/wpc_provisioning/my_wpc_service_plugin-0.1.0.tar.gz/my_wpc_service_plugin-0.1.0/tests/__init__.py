# -*- coding: UTF-8 -*-
#
# Copyright 2024 First Last
#
# SPDX-License-Identifier: MIT
"""Unit test package for my_wpc_service_plugin."""
