=======
History
=======

0.1.0 (2024-01-09)
------------------

* First release on PyPI.
