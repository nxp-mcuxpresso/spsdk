# -*- coding: UTF-8 -*-
#
# Copyright 2024 First Last
#
# SPDX-License-Identifier: MIT
"""Top-level package for My WPC Service Plugin."""

__author__ = """First Last"""
__email__ = "me@example.com"
__version__ = "0.1.0"

from .my_wpc_service_plugin import MyWPCService

__all__ = ["MyWPCService"]
